/*
 * attitudeKalmanfilter_types.h
 *
 * Code generation for function 'attitudeKalmanfilter'
 *
 * C source code generated on: Mon Oct 01 19:38:49 2012
 *
 */

#ifndef __ATTITUDEKALMANFILTER_TYPES_H__
#define __ATTITUDEKALMANFILTER_TYPES_H__

/* Type Definitions */

#endif
/* End of code generation (attitudeKalmanfilter_types.h) */
